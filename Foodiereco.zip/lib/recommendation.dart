import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'dart:async';

class recommend {
  // generate recommendations based on selected items
  static Future getRecommendations(List<String> seleitems, List<String> items, List<String> recommendations, List<int> freqofreco, Map cosinedist) async {
    recommendations = []; // set all previous recommendations to null an create a new
    freqofreco = List.filled(items.length, 0);
    int vegc = 0, masalac = 0, fryc = 0; // average veg, masala , fry an spicy levels of selecte items
    double spicysum = 0;
    for (int i = seleitems.length - 1; i >= 0; i--) {
      // for each element in selected items
      recommendations.add(seleitems[i]);
      //a the element in the recommendations as it can be ordered again with high probability
      freqofreco[items.indexOf(seleitems[i])]++;
      // frequency of that item should be increased
      final QueryBuilder<ParseObject> parseQuery = QueryBuilder<ParseObject>(ParseObject('FoodItems'));
      parseQuery.whereEqualTo('name', '${seleitems[i]}');
      //search for that selected item for more info
      final ParseResponse apiResponse = await parseQuery.query();
      for (var o in apiResponse.results!) {
        //update the values of the paramenters
        o['veg'] == true ? vegc++ : vegc = vegc;
        o['masala'] == true ? masalac++ : masalac = masalac;
        o['fry'] == true ? fryc++ : fryc = fryc;
        spicysum += o['spicy'];
      }
    }
    int a = (vegc > seleitems.length / 2) ? 1 : 0; //if more than half are veg then recommend veg
    int b = (masalac > seleitems.length / 2) ? 1 : 0; //similarly for masala an fry
    int c = (fryc > seleitems.length / 2) ? 1 : 0;
    double d = spicysum / seleitems.length; // average of the spicyness is preferre in recommendations
    cosinedist = Map<String, double>();
    final QueryBuilder<ParseObject> parseQuery = QueryBuilder<ParseObject>(ParseObject('Graph'));
    final ParseResponse apiResponse = await parseQuery.query();

    for (var o in apiResponse.results!) {
      cosinedist[o['name']] = d * d + a + b + c - (((o['paras'][0] * a) + (o['paras'][1] * b) + (o['paras'][2] * c) + (o['paras'][3] * d)));
    }
    double min = d * d + a + b + c + 1; //set min to its max possible
    int indmx = -1;
    //and index to the -1
    for (int h = 0; h < 5; h++) {
      // adding minimum of five recommendations
      min = d * d + a + b + c + 1;
      for (int i = 0; i < items.length; i++) {
        //traverse whole list and check min distamnce
        if (min > (cosinedist[items[i]]).abs()) {
          min = (cosinedist[items[i]]).abs();
          indmx = i;
          //update its min and index
        }
      }
      if (freqofreco[indmx] == 0) {
        // if frequency is 0 in recommendations list then add to the list
        recommendations.add(items[indmx]);
      }

      freqofreco[indmx]++;
      cosinedist[items[indmx]] = d * d + a + b + c + 1;
      // set to the max value so that in next iteration it won't be considered
    }
    return recommendations;
    //return list of recommendations
  }
}
