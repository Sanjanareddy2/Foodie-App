import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'dart:async';

class data {
  static void dosavedata(int ind, List<String> items) async {
    String objectId = '';
    //save some data as default
    var parseObject = ParseObject("SelectedItems")..set("name", "Curries");
    //save original data
    parseObject = ParseObject("SelectedItems")..set("name", "${items[ind]}");
    final ParseResponse parseResponse = await parseObject.save();
  }
}
