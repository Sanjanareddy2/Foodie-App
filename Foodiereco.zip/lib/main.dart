import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'recommendation.dart';
import 'deletedata.dart';
import 'savedata.dart';
import 'graph.dart';
import 'dart:async';

Map cosinedist = Map<String, double>(); // map between item name and the cosine distance

List<String> recommendations = []; // list of recommended items based on selected items

List<String> items = [
  //list of items available in the menu
  "Paneer Curry",
  "Chicken Curry",
  "Paneer Jalfrezi",
  "Palak Paneer",
  "Mutton Curry",
  "Kadai Muhroom",
  "Chicken Fry",
  "Aloo Palak",
  "Mutton Kofta",
  "Rajma Curry",
  "Ladies' Fingers Fry",
  "Prawn Curry",
  "Aloo Mutter Curry",
  "Capsicum Curry",
  "Kadai Chicken",
  "Brinjal Curry",
  "Chena Curry",
  "Fish Curry",
  "Ridge Gourd Curry",
  "Laal Maans"
];
List<int> freqofreco = List.filled(items.length, 0); // frequency of recommended items checks that no repitition happened
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final keyApplicationId = 'Jtl8xjxhVMWgtylXgBEoLUJMGnRIfzNDzOLpWKFb'; //application id of back4app of perticular database
  final keyClientKey = 'vZ7JWQ4PrsdsspXp2IzFvHClsaGhpCoR8eiSy0GP'; //similarly keyclientkey an parse server url
  final keyParseServerUrl = 'https://parseapi.back4app.com';

  Parse().initialize(keyApplicationId, keyParseServerUrl, clientKey: keyClientKey, autoSendSessionId: true);

  runApp(new MyApp());
}

class MyApp extends StatelessWidget {
  // a StatelessWidget because it has no parameters
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      // a nwe material app like structure which has a home as MyHomePage
      title: 'Flutter Demo',
      theme: new ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: new MyHomePage(title: 'Foodie App'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  //
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int gonce = 0;
  int indofsel = 0; // current index of selected items
  List<int> freq = List.filled(items.length, 0); //frequency of selected items

  List<String> selecteditems = []; //list of selected items

  @override
  Widget build(BuildContext context) {
    final _width = MediaQuery.of(context).size.width;
    final _height = MediaQuery.of(context).size.height;

    final headerList = new ListView.builder(
      itemBuilder: (context, index) {
        EdgeInsets padding = index == 0 ? const EdgeInsets.only(left: 20.0, right: 10.0, top: 4.0, bottom: 30.0) : const EdgeInsets.only(left: 10.0, right: 10.0, top: 4.0, bottom: 30.0);

        return new Padding(
          padding: padding,
          child: new InkWell(
            onTap: () {
              if (freq[index] == 0) {
                //adds data to the database only if it is not selected before.
                data.dosavedata(index, items);
              }
              // prints card is selected on terminal
              print('Card selected');
              if (gonce == 0) {
                graph.makeagraph(); //stroes a graph like data in the data base for recommendations
                gonce += 1; // ensures it happens only once
              }
              if (freq[index] == 0) {
                selecteditems.insert((indofsel++), items[index]);
              }

              freq[index] += 1;
              print(freq); // prints frequency of the selected items
              print(selecteditems); // prints all the selected items on terminal
              getreco(selecteditems); //get recommended items based on selecte items

              Timer _timer = new Timer(const Duration(seconds: 4), () {
                // adding time  of 4 sec manually to get all recommended items
                setState(() {});
              });
            },
            child: new Container(
              // a new container
              decoration: new BoxDecoration(
                // basically a design of a card
                borderRadius: new BorderRadius.circular(10.0),
                color: Colors.transparent,
                boxShadow: [
                  new BoxShadow(color: Colors.black.withAlpha(70), offset: const Offset(3.0, 10.0), blurRadius: 15.0)
                ],
                image: new DecorationImage(
                  image: new ExactAssetImage('images/img_${(index % items.length) + 1}.jpg'),
                  fit: BoxFit.fitHeight,
                ),
              ),
              height: 200.0, // cards height
              width: 200.0, // cards weight
              child: new Stack(
                children: <Widget>[
                  new Align(
                    alignment: Alignment.bottomCenter,
                    child: new Container(
                        decoration: new BoxDecoration(color: const Color(0xFF273A48), borderRadius: new BorderRadius.only(bottomLeft: new Radius.circular(10.0), bottomRight: new Radius.circular(10.0))),
                        height: 25.0,
                        child: new Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            new Text(
                              '${items[index % items.length]}', //prints the names
                              style: new TextStyle(color: Colors.white),
                            ),
                          ],
                        )),
                  )
                ],
              ),
            ),
          ),
        );
      },
      scrollDirection: Axis.vertical, // scrolling axis as vertical
      itemCount: items.length, // number of cards will be equal to number of items in the menu
    );

    final body = new Scaffold(
      appBar: new AppBar(
        title: new Text(widget.title),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        actions: <Widget>[
          new IconButton(
              icon: new Icon(
                Icons.refresh_outlined,
                color: Colors.white,
              ),
              onPressed: () {
                print('refresshed'); //prints refreshed on the terminal
                indofsel = 0; //current index of the selected items is zero
                freq = List.filled(items.length, 0); // make frequency of all items as zero
                selecteditems.length = 0; //length of selected items as 0
                deldata.deleteSelectedItems(); //delete all the selected items from the database
              })
        ],
      ),
      backgroundColor: Colors.transparent,
      body: new Container(
        // container to place a items available in the menu
        child: new Stack(
          children: <Widget>[
            new Padding(
              padding: new EdgeInsets.only(top: 10.0),
              child: new Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  new Align(
                    alignment: Alignment.centerLeft,
                    child: new Padding(
                        padding: new EdgeInsets.only(left: 8.0),
                        child: new Text(
                          'List of items', // prints the list of items on the top.
                          style: new TextStyle(
                            color: Colors.white70,
                            fontStyle: FontStyle.italic,
                            fontSize: 18.0,
                          ),
                        )),
                  ),
                  new Container(height: 300.0, width: _width, child: headerList),
                  new Expanded(
                      child: ListView.builder(
                          // list of recommeneded items
                          itemCount: recommendations.length,
                          itemBuilder: (context, index) {
                            return new ListTile(
                              title: new Column(
                                children: <Widget>[
                                  new Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      new Container(
                                        height: 72.0,
                                        width: 72.0,
                                        decoration: new BoxDecoration(
                                            // card design for recommended items
                                            color: Colors.lightGreen,
                                            boxShadow: [
                                              new BoxShadow(color: Colors.black.withAlpha(70), offset: const Offset(2.0, 2.0), blurRadius: 2.0)
                                            ],
                                            borderRadius: new BorderRadius.all(new Radius.circular(12.0)),
                                            image: new DecorationImage(
                                              image: new ExactAssetImage(
                                                'images/img_${items.indexOf(recommendations[index]) + 1}.jpg',
                                              ),
                                              fit: BoxFit.cover,
                                            )),
                                      ),
                                      new SizedBox(
                                        width: 8.0,
                                      ),
                                      new Expanded(
                                          child: new Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: <Widget>[
                                          new Text(
                                            // text at the side of the phote of the recommended items
                                            'Recommended ${recommendations[index]}',
                                            style: new TextStyle(fontSize: 14.0, color: Colors.black87, fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      )),
                                      new Icon(
                                        Icons.shopping_cart,
                                        color: const Color(0xFF273A48),
                                      )
                                    ],
                                  ),
                                  new Divider(),
                                ],
                              ),
                            );
                          }))
                ],
              ),
            ),
          ],
        ),
      ),
    );

    return new Container(
      decoration: new BoxDecoration(
        color: const Color(0xFF273A48),
      ),
      child: new Stack(
        children: <Widget>[
          new CustomPaint(
            size: new Size(_width, _height),
          ),
          body,
        ],
      ),
    );
  }
}

void getreco(List<String> recoitems) async {
  recommendations = await recommend.getRecommendations(recoitems, items, recommendations, freqofreco, cosinedist);
  //wait untill the recommendations are returned from the function
  return;
}
