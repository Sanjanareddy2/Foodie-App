import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'dart:async';

class deldata {
  static void deleteSelectedItems() async {
    final QueryBuilder<ParseObject> parseQuery = QueryBuilder<ParseObject>(ParseObject('SelectedItems'));
    final ParseResponse apiResponse = await parseQuery.query();
    //fetch all the selecte items and delete on clicking the refresh button
    for (var o in apiResponse.results!) {
      var todelete = ParseObject('SelectedItems')..objectId = o.objectId;
      await todelete.delete();
    }
  }
}
