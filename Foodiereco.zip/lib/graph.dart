import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'dart:async';

class graph {
  static void deleteGraph() async {
    final QueryBuilder<ParseObject> parseQuery = QueryBuilder<ParseObject>(ParseObject('Graph'));
    final ParseResponse apiResponse = await parseQuery.query();
    //delete each an every element available in the graph
    for (var o in apiResponse.results!) {
      //print(o.objectId);
      var todelete = ParseObject('Graph')..objectId = o.objectId;
      await todelete.delete();
    }
  }

  static void makeagraph() async {
    deleteGraph(); // make sure that in database the graph class is empty
    final QueryBuilder<ParseObject> parseQuery = QueryBuilder<ParseObject>(ParseObject('FoodItems'));
    final ParseResponse apiResponse = await parseQuery.query();
    //creating an array for the items available in the menu
    //this is similar to the coordinates of the graph
    for (var o in apiResponse.results!) {
      final graph = ParseObject('Graph')
        ..set('name', o['name'])
        ..set('paras', [
          (o['veg'] == true) ? 1 : 0,
          (o['masala'] == true) ? 1 : 0,
          (o['fry'] == true) ? 1 : 0,
          o['spicy']
        ]);

      await graph.save();
    }
  }
}
